<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <title>E-UMKM Bumi Reyog Ponorogo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style6.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">Classy</label>
      <ul>
        <li><a class="active" href="home.php">Home</a></li>
        <li><a href="akun_konsumen">Akun</a></li>
        <li><a href="#">Pendaftaran</a></li>
        <li><a href="daftar_produk.php">Daftar Toko</a></li>
        <li><a href="#">Logout</a></li>
      </ul>
    </nav>
	<title>E-UMKM Bumi Reyog Ponorogo</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	<div class="signup-box">
		<h1>Beli Produk</h1>
		<form>
			<input type="text" name="ID pengusaha" placeholder="Masukkan ID">
			<input type="text" name="ID Konsumen" placeholder="Masukkan IDr">
			<input type="text" name="Nama" placeholder="Masukkan Nama">
			<input type="text" name="Produk Beli" placeholder="Masukkan Nama Produk">
			<input type="number" name="Jumlah" placeholder="Masukkan Jumlah Beli">
			<input type="text" name="Keterangan" placeholder="Masukkan Keterangan">
			<input type="submit" name="submit" value="Beli">
		</form>
		
	</div>

</body>
</html>
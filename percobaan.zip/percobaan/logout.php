<?php
setcookie("nama","");
header("Location: home.php?logout=success");
?>
<!DOCTYPE html>
<html>
<head>
	<title>E-UMKM Bumi Reyog Ponorogo</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	<form action="akun.php" method="post" enctype="multipart/form-data" name="form2" id="form2">
	<div class="signup-box">
		<img src="avatar.jpg" class="avatar">
		<h1>Daftar</h1>
		<form>
			<input type="text" name="Nama" placeholder="Masukkan Nama">
			<input type="number" name="Nomer Telepon" placeholder="Masukkan Nomer">
			<input type="email" name="Email" placeholder="Masukkan Email">
			<input type="Password" name="Password" placeholder="Masukkan Password">
			<input type="submit" name="submit" value="Daftar">
			<p class="signup-login-text">Sudah Memiliki Akun? <a href="gabung.php">Gabung Disini</a></p>
		</form>
		
	</div>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>E-UMKM Bumi Reyog Ponorogo</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
	<form action="akun2.php" method="post" enctype="multipart/form-data" name="form2" id="form2">
	<div class="login-box">
		<img src="avatar.jpg" class="avatar">
		<h1>Gabung</h1>
		<form>
			<input type="text" name="Email" placeholder="Masukkan Nama">
			<input type="Password" name="Password" placeholder="Masukkan Password">
			<input type="submit" name="submit" value="Gabung">
			<p class="login-register-text">Belum Memiliki Akun? <a href="daftar.php">Daftar Disini</a>.</p>
		</form>
		
	</div>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <title>E-UMKM Bumi Reyog Ponorogo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">Classy</label>
      <ul>
        <li><a class="active" href="home.php">Home</a></li>
        <li><a href="akun_konsumen.php">Akun</a></li>
        <li><a href="pendaftaran.php">Pendaftaran</a></li>
        <li><a href="daftar_produk.php">Daftar Toko</a></li>
        <li><a href="#">Logout</a></li>
      </ul>
    </nav>
	<title>E-UMKM Bumi Reyog Ponorogo</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	<div class="signup-box">
		<img src="avatar.jpg" class="avatar">
		<h1>Pendaftaran UMKM</h1>
		<form>
			<input type="text" name="Nama" placeholder="Masukkan Nama">
			<input type="text" name="Nama Toko" placeholder="Masukkan Nama Toko">
			<input type="text" name="Alamat" placeholder="Masukkan Alamat">
			<input type="text" name="Daftar Produk" placeholder="Masukkan Daftar Produk">
			<input type="text" name="Harga" placeholder="Masukkan Harga">
			<input type="text" name="Deskripsi" placeholder="Masukkan Deskripsi">
			<input type="submit" name="submit" value="Daftar">
		</form>
		
	</div>

</body>
</html>